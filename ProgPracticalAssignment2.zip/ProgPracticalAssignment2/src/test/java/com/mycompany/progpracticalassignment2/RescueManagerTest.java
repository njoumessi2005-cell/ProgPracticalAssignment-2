/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.progpracticalassignment2;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author VALBUSENT
 */
public class RescueManagerTest {
    
    public RescueManagerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addCase method, of class RescueManager.
     */
    @Test
    public void testAddCase() {
        System.out.println("addCase");
        RescueCase rescueCase = null;
        RescueManager instance = new RescueManager();
        instance.addCase(rescueCase);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of idExists method, of class RescueManager.
     */
    @Test
    public void testIdExists() {
        System.out.println("idExists");
        String id = "";
        RescueManager instance = new RescueManager();
        boolean expResult = false;
        boolean result = instance.idExists(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findById method, of class RescueManager.
     */
    @Test
    public void testFindById() {
        System.out.println("findById");
        String id = "";
        RescueManager instance = new RescueManager();
        RescueCase expResult = null;
        RescueCase result = instance.findById(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateStatus method, of class RescueManager.
     */
    @Test
    public void testUpdateStatus() {
        System.out.println("updateStatus");
        String id = "";
        RescueStatus newStatus = null;
        RescueManager instance = new RescueManager();
        boolean expResult = false;
        boolean result = instance.updateStatus(id, newStatus);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAllCases method, of class RescueManager.
     */
    @Test
    public void testGetAllCases() {
        System.out.println("getAllCases");
        RescueManager instance = new RescueManager();
        List<RescueCase> expResult = null;
        List<RescueCase> result = instance.getAllCases();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCaseCount method, of class RescueManager.
     */
    @Test
    public void testGetCaseCount() {
        System.out.println("getCaseCount");
        RescueManager instance = new RescueManager();
        int expResult = 0;
        int result = instance.getCaseCount();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalEstimatedCost method, of class RescueManager.
     */
    @Test
    public void testGetTotalEstimatedCost() {
        System.out.println("getTotalEstimatedCost");
        RescueManager instance = new RescueManager();
        double expResult = 0.0;
        double result = instance.getTotalEstimatedCost();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateReport method, of class RescueManager.
     */
    @Test
    public void testGenerateReport() {
        System.out.println("generateReport");
        RescueManager instance = new RescueManager();
        String expResult = "";
        String result = instance.generateReport();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
